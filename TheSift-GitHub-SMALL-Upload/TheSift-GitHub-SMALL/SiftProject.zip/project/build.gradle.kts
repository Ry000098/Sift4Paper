plugins {
    java
}

group = "mielon.thesift"
version = "1.1.2-paper.26.3"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:26.3.build.+")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

java { withSourcesJar() }

tasks.named<Jar>("jar") {
    archiveBaseName.set("TheSift-Paper")
}
