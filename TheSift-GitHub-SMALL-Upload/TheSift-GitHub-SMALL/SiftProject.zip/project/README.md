# The Sift — Paper 26.3 Port

This is a **port project**, not a renamed Fabric JAR.

The original The Sift 1.1.2 resource/data material has been preserved so the Paper implementation can reproduce the original content instead of becoming a simplified remake.

## Build

Use JDK 25 and Gradle, then run:

```text
gradle build
```

The resulting plugin is under `build/libs/`.

## Current state

The included plugin is a safe Paper 26.3 foundation with diagnostics and configuration. The original Fabric classes are deliberately not loaded: doing so would still require Fabric Loader/API and would not be a Paper conversion.

The `port-assets/` directory contains the original non-weapon resource/data source material for the next implementation layers.

## Important

Do not put the original Fabric mod JAR into the Paper `plugins` folder expecting this project to make it work. It is a separate Fabric mod and must not be loaded by Paper.
