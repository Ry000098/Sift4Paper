package mielon.thesift.paper;

import java.util.Random;
import org.bukkit.HeightMap;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;
import org.bukkit.generator.BiomeProvider;

/**
 * P2 server-side approximation of The Sift terrain.
 * The original datapack/noise graph is preserved in resources; this generator
 * makes the dimension playable before custom Fabric block/fluid registries are replaced.
 */
public final class SiftDimensionGenerator extends ChunkGenerator {
    private static double noise(long seed, int x, int z, double scale) {
        double a = Math.sin((x + seed * 0.00013) * scale);
        double b = Math.cos((z - seed * 0.00017) * scale * 1.13);
        double c = Math.sin((x + z) * scale * 0.47 + seed * 0.00001);
        return (a + b + c) / 3.0;
    }

    @Override
    public void generateNoise(WorldInfo worldInfo, Random random, int chunkX, int chunkZ, ChunkData data) {
        long seed = worldInfo.getSeed();
        int minY = Math.max(data.getMinHeight(), 0);
        int maxY = Math.min(data.getMaxHeight(), 256);
        for (int lx = 0; lx < 16; lx++) for (int lz = 0; lz < 16; lz++) {
            int x = chunkX * 16 + lx, z = chunkZ * 16 + lz;
            double continental = noise(seed, x, z, 0.0045);
            double ridges = Math.abs(noise(seed + 91, x, z, 0.012));
            double detail = noise(seed + 173, x, z, 0.035);
            int surface = (int)Math.round(72 + continental * 34 + ridges * 30 + detail * 7);
            surface = Math.max(minY + 6, Math.min(maxY - 2, surface));

            data.setBlock(lx, minY, lz, Material.BEDROCK);
            for (int y = minY + 1; y <= surface; y++) {
                Material m = y < surface - 4 ? Material.DEEPSLATE : Material.TUFF;
                data.setBlock(lx, y, lz, m);
            }
            // Wastes / overgrown visual regions using vanilla stand-ins.
            double wet = noise(seed + 501, x, z, 0.006);
            if (wet > 0.18) {
                data.setBlock(lx, surface, lz, Material.MOSS_BLOCK);
                if (random.nextDouble() < 0.055 && surface + 1 < maxY) data.setBlock(lx, surface + 1, lz, Material.SCULK);
            } else if (surface > 118) {
                data.setBlock(lx, surface, lz, Material.CALCITE);
            } else {
                data.setBlock(lx, surface, lz, Material.DEEPSLATE);
            }
        }
    }

    @Override public boolean shouldGenerateCaves() { return true; }
    @Override public boolean shouldGenerateDecorations() { return true; }
    @Override public boolean shouldGenerateMobs() { return true; }
    @Override public boolean shouldGenerateStructures() { return true; }
    @Override public BiomeProvider getDefaultBiomeProvider(WorldInfo worldInfo) { return null; }
}
