package mielon.thesift.paper;

import java.util.List;

/** Catalog recovered from Mielon's 1.1.2 Fabric jar. */
public final class OriginalContent {
    private OriginalContent() {}

    public static final List<String> CORE_ITEMS = List.of(
        "ichor_shard", "charoite", "siftite_nugget", "siftite_ingot", "ichor_snowball",
        "ichor_bottle", "raw_sifter_meat", "cooked_sifter_meat", "sift_rift", "music_disc_rift",
        "music_disc_wellspring", "sculkflower_seeds", "siftite_sword", "siftite_shovel",
        "siftite_pickaxe", "siftite_axe", "siftite_hoe", "siftite_spear", "siftite_helmet",
        "siftite_chestplate", "siftite_leggings", "siftite_boots", "siftite_upgrade_smithing_template"
    );

    public static final List<String> ENTITIES = List.of(
        "singer", "echo_golem", "dark_sniffer", "sifter", "blub", "rift", "mini_rift", "siftite_return"
    );

    public static final List<String> BIOMES = List.of(
        "sift_wastes", "siftslate_slopes", "siftslate_peaks", "ichor_snowy_peaks", "sift_deep_dark",
        "overgrown_forest", "overgrown_forest_slopes", "overgrown_slopes", "overgrown_clearing", "overgrown_peaks"
    );
}
