package mielon.thesift.paper;

import java.nio.file.Path;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class TheSiftPaperPlugin extends JavaPlugin implements PackExporter.JavaPluginLike {
    public static final String VERSION = "1.1.2-paper.26.3-sift-v1-alpha";
    private SiftMobs siftMobs;
    public static final String SIFT_WORLD = "the_sift";

    @Override public Path dataFolder() { return getDataFolder().toPath(); }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getLogger().info("The Sift Paper port P2 dimension build enabled.");
        getLogger().info("Bundled original reference: 428 data files + 597 client asset files.");
        siftMobs = new SiftMobs(this);
        getServer().getPluginManager().registerEvents(new SiftPortalListener(this), this);
        getServer().getPluginManager().registerEvents(new SiftMobListener(siftMobs), this);
        getServer().getScheduler().runTaskTimer(this, () -> siftMobs.populateNearPlayers(), 200L, 200L);
        getLogger().info("Sift V1 alpha: dimension, reinforced-deepslate note-activated portals, and first-pass Sift creatures enabled.");
    }

    @Override public void onDisable() { getLogger().info("The Sift Paper port disabled."); }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("sift")) return false;
        if (!sender.hasPermission("thesift.admin")) { sender.sendMessage("You do not have permission."); return true; }
        String sub = args.length == 0 ? "status" : args[0].toLowerCase();
        switch (sub) {
            case "info", "status" -> {
                sender.sendMessage("§5The Sift §7Paper 26.3 port §f" + VERSION);
                sender.sendMessage("§7Reference data: §a428 §7files | client assets: §a597 §7files");
                sender.sendMessage("§7Catalog: §f" + OriginalContent.CORE_ITEMS.size() + " core items, " + OriginalContent.ENTITIES.size() + " entities, " + OriginalContent.BIOMES.size() + " biomes");
                sender.sendMessage("§7Current milestone: §eSift V1 alpha gameplay build");
                sender.sendMessage("§7Dimension: §f" + (Bukkit.getWorld(SIFT_WORLD) == null ? "not created" : "loaded"));
            }
            case "catalog" -> {
                sender.sendMessage("§dItems: §f" + String.join(", ", OriginalContent.CORE_ITEMS));
                sender.sendMessage("§dEntities: §f" + String.join(", ", OriginalContent.ENTITIES));
                sender.sendMessage("§dBiomes: §f" + String.join(", ", OriginalContent.BIOMES));
            }
            case "export" -> {
                try { sender.sendMessage("§aExported original data/assets to §f" + PackExporter.export(this)); }
                catch (Exception e) { sender.sendMessage("§cExport failed: " + e.getMessage()); getLogger().warning(e.toString()); }
            }
            case "dimension", "dim" -> {
                String action = args.length > 1 ? args[1].toLowerCase() : "status";
                if (action.equals("create")) {
                    World world = ensureSiftWorld();
                    sender.sendMessage("§aThe Sift world is loaded: §f" + world.getName());
                } else if (action.equals("enter")) {
                    if (!(sender instanceof Player player)) { sender.sendMessage("§cPlayers only."); break; }
                    World world = ensureSiftWorld();
                    enterSift(player);
                } else if (action.equals("leave")) {
                    if (!(sender instanceof Player player)) { sender.sendMessage("§cPlayers only."); break; }
                    leaveSift(player);
                } else {
                    World world = Bukkit.getWorld(SIFT_WORLD);
                    sender.sendMessage("§7Sift dimension: §f" + (world == null ? "not loaded" : "loaded, seed " + world.getSeed()));
                    sender.sendMessage("§7Use: /sift dimension <create|enter|leave|status>");
                }
            }
            case "mob", "spawn" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("§cPlayers only."); break; }
                String kind = args.length > 1 ? args[1].toLowerCase() : "singer";
                try { siftMobs.spawn(kind, player.getLocation().clone().add(2, 0, 2)); sender.sendMessage("§aSpawned Sift mob: §f" + kind); }
                catch (IllegalArgumentException ex) { sender.sendMessage("§cUse singer, echo_golem, dark_sniffer, sifter, or blub."); }
            }
            case "portal" -> { sender.sendMessage("§dPortal: §fBuild a reinforced-deepslate rectangle (minimum 3x3 total size), leave the inside empty, and play a nearby note block. Walk into the activated portal to enter/leave The Sift."); }
            case "reload" -> { reloadConfig(); sender.sendMessage("§aConfiguration reloaded."); }
            default -> sender.sendMessage("§7Usage: /sift <status|catalog|dimension|mob|portal|export|reload>");
        }
        return true;
    }

    public void enterSift(Player player) {
        World world=ensureSiftWorld(); int y=world.getHighestBlockYAt(0,0)+2; player.teleport(new Location(world,.5,y,.5));
        player.sendMessage("§5You pass through the rift into The Sift.");
    }
    public void leaveSift(Player player) {
        World world=Bukkit.getWorlds().getFirst(); player.teleport(world.getSpawnLocation()); player.sendMessage("§aYou return from The Sift.");
    }

    private World ensureSiftWorld() {
        World existing = Bukkit.getWorld(SIFT_WORLD);
        if (existing != null) return existing;
        WorldCreator creator = new WorldCreator(SIFT_WORLD);
        creator.environment(World.Environment.NORMAL);
        creator.generator(new SiftDimensionGenerator());
        creator.generateStructures(true);
        World world = creator.createWorld();
        if (world == null) throw new IllegalStateException("Paper failed to create The Sift world");
        world.setSpawnLocation(0, world.getHighestBlockYAt(0, 0, org.bukkit.HeightMap.MOTION_BLOCKING_NO_LEAVES) + 2, 0);
        return world;
    }
}
