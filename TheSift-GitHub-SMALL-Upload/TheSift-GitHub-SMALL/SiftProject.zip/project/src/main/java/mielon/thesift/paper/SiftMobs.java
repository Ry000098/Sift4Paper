package mielon.thesift.paper;

import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

/** Server-side Paper stand-ins for the original Sift mobs until custom entity registries/client renderers are available. */
public final class SiftMobs {
    private final JavaPlugin plugin;
    private final NamespacedKey kindKey;
    public SiftMobs(JavaPlugin plugin) { this.plugin = plugin; this.kindKey = new NamespacedKey(plugin, "sift_mob"); }

    public LivingEntity spawn(String kind, Location at) {
        String k = kind.toLowerCase(Locale.ROOT);
        LivingEntity mob = switch (k) {
            case "singer" -> at.getWorld().spawn(at, Warden.class);
            case "echo_golem" -> at.getWorld().spawn(at, IronGolem.class);
            case "dark_sniffer" -> at.getWorld().spawn(at, Sniffer.class);
            case "sifter" -> at.getWorld().spawn(at, Ravager.class);
            case "blub" -> at.getWorld().spawn(at, Slime.class);
            default -> throw new IllegalArgumentException("Unknown Sift mob: " + kind);
        };
        mob.getPersistentDataContainer().set(kindKey, PersistentDataType.STRING, k);
        mob.customName(net.kyori.adventure.text.Component.text(display(k)));
        mob.setCustomNameVisible(true);
        tune(k, mob);
        return mob;
    }

    public String kind(Entity e) { return e.getPersistentDataContainer().get(kindKey, PersistentDataType.STRING); }

    private void tune(String k, LivingEntity e) {
        switch (k) {
            case "singer" -> { set(e, Attribute.MAX_HEALTH, 120); e.setHealth(120); set(e, Attribute.MOVEMENT_SPEED, 0.24); }
            case "echo_golem" -> { set(e, Attribute.MAX_HEALTH, 80); e.setHealth(80); set(e, Attribute.MOVEMENT_SPEED, 0.22); }
            case "dark_sniffer" -> { set(e, Attribute.MAX_HEALTH, 40); e.setHealth(40); }
            case "sifter" -> { set(e, Attribute.MAX_HEALTH, 55); e.setHealth(55); set(e, Attribute.MOVEMENT_SPEED, 0.28); }
            case "blub" -> { set(e, Attribute.MAX_HEALTH, 18); e.setHealth(18); if (e instanceof Slime s) s.setSize(2); }
        }
    }
    private static void set(LivingEntity e, Attribute a, double v) { var x=e.getAttribute(a); if(x!=null)x.setBaseValue(v); }
    private static String display(String k) { StringBuilder b=new StringBuilder(); for(String p:k.split("_")) b.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(' '); return b.toString().trim(); }

    public void populateNearPlayers() {
        World w = plugin.getServer().getWorld(TheSiftPaperPlugin.SIFT_WORLD); if (w == null) return;
        for (Player p : w.getPlayers()) {
            long nearby = p.getNearbyEntities(40, 24, 40).stream().filter(x -> kind(x) != null).count();
            if (nearby >= 6 || ThreadLocalRandom.current().nextInt(100) > 12) continue;
            String[] pool={"blub","sifter","dark_sniffer","echo_golem"}; String k=pool[ThreadLocalRandom.current().nextInt(pool.length)];
            Location l=p.getLocation().clone().add(ThreadLocalRandom.current().nextInt(-28,29),0,ThreadLocalRandom.current().nextInt(-28,29));
            int y=w.getHighestBlockYAt(l.getBlockX(),l.getBlockZ())+1; l.setY(y); spawn(k,l);
        }
    }
}
