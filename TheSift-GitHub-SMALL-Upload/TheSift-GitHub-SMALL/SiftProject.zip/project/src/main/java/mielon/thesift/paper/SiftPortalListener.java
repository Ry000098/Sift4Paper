package mielon.thesift.paper;

import java.util.HashSet;
import java.util.Set;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.NotePlayEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;

/** Reinforced-deepslate portal frame based on the original PortalFrameScanner/PortalAutoActivation. */
public final class SiftPortalListener implements Listener {
    private final TheSiftPaperPlugin plugin;
    private final Set<String> active = new HashSet<>();
    public SiftPortalListener(TheSiftPaperPlugin plugin){this.plugin=plugin;}

    @EventHandler public void onNote(NotePlayEvent e) {
        // Original mod searches for reinforced-deepslate frames near played notes.
        Block note=e.getBlock();
        for(int x=-10;x<=10;x++) for(int y=-10;y<=10;y++) for(int z=-10;z<=10;z++) {
            Block b=note.getRelative(x,y,z); if(b.getType()!=Material.REINFORCED_DEEPSLATE) continue;
            Portal p=scan(b); if(p!=null){ activate(p); return; }
        }
    }

    @EventHandler public void onMove(PlayerMoveEvent e) {
        if(e.getTo()==null || e.getFrom().getBlockX()==e.getTo().getBlockX()&&e.getFrom().getBlockY()==e.getTo().getBlockY()&&e.getFrom().getBlockZ()==e.getTo().getBlockZ()) return;
        Player p=e.getPlayer(); Block b=e.getTo().getBlock(); if(b.getType()!=Material.NETHER_PORTAL) return;
        if(!active.contains(key(b))) return;
        if(p.getWorld().getName().equals(TheSiftPaperPlugin.SIFT_WORLD)) plugin.leaveSift(p); else plugin.enterSift(p);
    }

    private void activate(Portal p){
        for(Block b:p.inside){ b.setType(Material.NETHER_PORTAL,false); active.add(key(b)); b.getWorld().spawnParticle(Particle.SCULK_SOUL,b.getLocation().add(.5,.5,.5),12,.3,.4,.3,.02); }
        p.anchor.getWorld().playSound(p.anchor.getLocation(),Sound.BLOCK_PORTAL_TRIGGER,1f,.65f);
    }
    private Portal scan(Block start){ Portal p=scanAxis(start,true); return p!=null?p:scanAxis(start,false); }
    private Portal scanAxis(Block start, boolean xAxis){
        for(int ox=-22;ox<=0;ox++) for(int oy=-22;oy<=0;oy++) {
            Block base=start.getRelative(xAxis?ox:0,oy,xAxis?0:ox);
            if(base.getType()!=Material.REINFORCED_DEEPSLATE) continue;
            for(int w=3;w<=23;w++) {
                Block far=base.getRelative(xAxis?w-1:0,0,xAxis?0:w-1);
                if(far.getType()!=Material.REINFORCED_DEEPSLATE) continue;
                for(int h=3;h<=23;h++) {
                    boolean contains=false,ok=true; var inside=new java.util.ArrayList<Block>();
                    for(int aa=0;aa<w&&ok;aa++) for(int yy=0;yy<h;yy++) {
                        Block bb=base.getRelative(xAxis?aa:0,yy,xAxis?0:aa); boolean edge=aa==0||aa==w-1||yy==0||yy==h-1;
                        if(bb.equals(start))contains=true;
                        if(edge){if(bb.getType()!=Material.REINFORCED_DEEPSLATE){ok=false;break;}}
                        else {if(!bb.isEmpty()&&bb.getType()!=Material.GLOW_LICHEN){ok=false;break;} inside.add(bb);}
                    }
                    if(ok&&contains&&!inside.isEmpty()) return new Portal(start,inside);
                }
            }
        } return null;
    }
    private static String key(Block b){return b.getWorld().getUID()+":"+b.getX()+":"+b.getY()+":"+b.getZ();}
    private record Portal(Block anchor, java.util.List<Block> inside){}
}
