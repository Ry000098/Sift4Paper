package mielon.thesift.paper;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;

/** Gameplay hooks for the first server-side versions of the original Sift creatures. */
public final class SiftMobListener implements Listener {
 private final SiftMobs mobs; public SiftMobListener(SiftMobs mobs){this.mobs=mobs;}
 @EventHandler public void death(EntityDeathEvent e){ String k=mobs.kind(e.getEntity()); if(k==null)return; e.getDrops().clear();
   switch(k){case "sifter"->e.getDrops().add(new ItemStack(Material.COOKED_BEEF,1)); case "singer"->e.getDrops().add(new ItemStack(Material.ECHO_SHARD,2)); case "echo_golem"->e.getDrops().add(new ItemStack(Material.AMETHYST_SHARD,2)); case "blub"->e.getDrops().add(new ItemStack(Material.SLIME_BALL,2)); default->{} }
 }
 @EventHandler public void hit(EntityDamageByEntityEvent e){ String k=mobs.kind(e.getDamager()); if(k==null)return; if(k.equals("singer")){e.getEntity().getWorld().spawnParticle(Particle.SONIC_BOOM,e.getEntity().getLocation().add(0,1,0),1); e.getEntity().getWorld().playSound(e.getEntity().getLocation(),Sound.ENTITY_WARDEN_SONIC_BOOM,.6f,1.1f);} }
}
