package mielon.thesift.paper;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.Enumeration;
import java.util.jar.*;
import java.util.zip.*;

/** Exports the original mod's data and client assets from this plugin jar for testing. */
public final class PackExporter {
    private PackExporter() {}

    public static Path export(JavaPluginLike plugin) throws IOException {
        Path out = plugin.dataFolder().resolve("exported");
        Files.createDirectories(out);
        Path zip = out.resolve("TheSift-original-resources-1.1.2.zip");
        URL location = PackExporter.class.getProtectionDomain().getCodeSource().getLocation();
        if (!"file".equals(location.getProtocol())) throw new IOException("Unsupported plugin code source: " + location);
        Path source = Path.of(URI.create(location.toString()));
        try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(zip))) {
            if (Files.isDirectory(source)) {
                Path root = source.resolve("original");
                if (Files.exists(root)) Files.walk(root).filter(Files::isRegularFile).forEach(p -> add(zos, root, p));
            } else {
                try (JarFile jar = new JarFile(source.toFile())) {
                    Enumeration<JarEntry> entries = jar.entries();
                    while (entries.hasMoreElements()) {
                        JarEntry e = entries.nextElement();
                        if (e.isDirectory() || !e.getName().startsWith("original/")) continue;
                        String name = e.getName().substring("original/".length());
                        zos.putNextEntry(new ZipEntry(name));
                        try (InputStream in = jar.getInputStream(e)) { in.transferTo(zos); }
                        zos.closeEntry();
                    }
                }
            }
        }
        return zip;
    }

    private static void add(ZipOutputStream zos, Path root, Path file) {
        try {
            zos.putNextEntry(new ZipEntry(root.relativize(file).toString().replace('\\', '/')));
            Files.copy(file, zos);
            zos.closeEntry();
        } catch (IOException ex) { throw new UncheckedIOException(ex); }
    }

    public interface JavaPluginLike { Path dataFolder(); }
}
